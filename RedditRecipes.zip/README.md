# RedditRecipes
A Firefox extensions for cataloging recipes from Reddit 
